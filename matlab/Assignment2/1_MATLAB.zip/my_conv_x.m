function [Cx] = my_conv_x(I,K)
%question1: This function creates grayscale image containing four squares
%   This function create a gray scale image of size dxd and draw a square of size d/2xd/2 
%   at the center of image with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your image has four squares

    k_width = 3;
    
    C = padarray(I,[1 0]);
    
    % A GENERALAZED CONVOLUTION COMPUTING CODE IN MATLAB WITHOUT USING MATLAB BUILTIN FUNCTION conv(x,h)
    for j=1:10
        C(:,j) = conv(I(:,j),K)
    end

    Cx = C(2:11,:);
end