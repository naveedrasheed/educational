function [G] = get_my_guassian_filter(sigma)
%question1: This function creates grayscale image containing four squares
%   This function create a gray scale image of size dxd and draw a square of size d/2xd/2 
%   at the center of image with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your image has four squares

    d = get_my_guassian_dim(sigma);

    G = zeros(d);

    xx = [-1:1];
    yy = [-1:1];
    
    for x = -1:1
        for y = -1:1
            G(x+2,y+2) = (1 / (sigma * sqrt(2 * pi))) * exp(-0.5 * (x^2 + y^2) / sigma ^2);
        end
    end
    
    % Is this equation really separable
    
    %factor = 255 / G(2,2);
    %G = factor * G;
    %G = uint8(round(G)); 
end