close all
clear all

I = (zeros(10));

C1 = [1;2;3];
C2 = [1;2;3];
C3 = conv(C1,C2)

x = 2;
y = 5;
sigma = 0.5;

I(x, 1:y) = 255;

for i = 1:5
    y = y+1;
    x = x+1;
    I(x,y) = 255;
end

I(:,1)

Gx = get_my_guassian_x_filter(sigma);
Ix = my_conv_x(I,Gx)

Gy = get_my_guassian_y_filter(sigma);
Ismooth = my_conv_y(Ix,Gy)

%G = Gx * Gy;
%Igsmooth = conv2(I,G);
%Igsmooth = Igsmooth(2:11, 2:11);



