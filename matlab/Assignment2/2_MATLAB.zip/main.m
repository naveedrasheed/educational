close all
clear all

[2;3;4;3;2] * [-1 -0.5 0 0.5 1]

I = (zeros(10));
Ig = (zeros(10));
Ia = (zeros(10));

x = 2;
y = 5;
sigma = 1;

I(x, 1:y) = 255;
I(3:10, y) = 255;

%for i = 1:5
%    y = y+1;
%    x = x+1;
%    I(x,y) = 255;
%end

Hx = get_my_guassian_x_filter(sigma);
Ix = conv2(I,Hx);
Ix = Ix(2:11, 2:11);

Hy = get_my_guassian_y_filter(sigma);
Iy = conv2(I,Hy);
Iy = Iy(2:11, 2:11);

for i = 1:10
    for j = 1:10
        Ig(i,j) = sqrt((Ix(i,j) ^2) + (Iy(i,j) ^2));
        %Ia(i,j) = atan2(Iy(i,j),Ix(i,j));
        Ia(i,j) = atan2(Ix(i,j),Iy(i,j));
    end
end

figure
subplot(2,1,1);
imagesc(Ig)

subplot(2,1,2);
imagesc(Ia)
close all

for i = 1:10
    for j = 1:10
        if(Ia(i,j) <= 0)
            Ia(i,j) = 0;
        else
            Ia(i,j) = 90;
        end
    end
end

Igp = padarray(Ig,[1 1]);
Iap = padarray(Ia,[1 1]);

for i = 2:11
    for j = 2:11
        if(Iap(i,j) == 0)
            if(Igp(i,j) < Igp(i+1,j) || Igp(i,j) < Igp(i-1,j))
               Igp(i,j) = 0;
            end
        end
        
        if(Iap(i,j) == 90)
            if(Igp(i,j) < Igp(i,j+1) || Igp(i,j) < Igp(i,j-1))
               Igp(i,j) = 0;
            end
        end
    end
end

Igp = Igp(2:11, 2:11);
maxx = max(max(Igp));
Igp = Igp / maxx;

Th = 0.8;
Tl = 0.7;

for i = 1:10
    for j = 1:10
        if(Igp(i,j) < Tl)
            Igp(i,j) = 0;
        end
    end
end

%G = Gx * Gy;
%Igsmooth = conv2(I,G);
%Igsmooth = Igsmooth(2:11, 2:11);