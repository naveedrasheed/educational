function [Hx] = get_my_guassian_x_filter(sigma)
%question1: This function creates Hrayscale imaHe containinH four squares
%   This function create a Hray scale imaHe of size dxd and draw a square of size d/2xd/2 
%   at the center of imaHe with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your imaHe has four squares

    d = get_my_guassian_dim(sigma);
    offset = floor(d/2);

    H = zeros(d,1);
    D = zeros(1,d);
    
    for x = -offset:offset
       H(x+offset + 1) = (1 / (sigma * sqrt(2 * pi))) * exp(-0.5 * x^2 / sigma ^2);
    end
    
    %D(1) = -offset;
    %for y = -offset+1:offset
    %   D(y+offset + 1) = D(y+offset) + 1;
    %end
    
    D(1) = -1 * (offset - 1);
    for y = -offset+1:-1
       D(y+offset + 1) = D(y+offset) - 1;
    end
    
    D(y+offset+2) = 0;
    D(y+offset+3) = offset;
    for y = 2:offset
       D(y+offset + 1) = D(y+offset) - 1;
    end
    
    Hx = H * D;
    %imagesc(Hx)
    %mesh(Hx)
    
    maxx = max(max(Hx));
    Hx = Hx / maxx;
    %imagesc(Hx)
    
    Hx = Hx * 255;
    %imagesc(Hx)
    
    Hx = round(Hx);
    %imagesc(Hx)
    
    %factor = 255 / Hx(2);
    %Hx = factor * Hx;
    %Hx = uint8(round(Hx));    
end