function [Hy] = get_my_guassian_y_filter(sigma)
%question1: This function creates grayscale image containing four squares
%   This function create a gray scale image of size dxd and draw a square of size d/2xd/2 
%   at the center of image with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your image has four squares

    d = get_my_guassian_dim(sigma);
    offset = floor(d/2);

    H = zeros(1,d);
    D = zeros(d,1);
    
    for y = -offset:offset
       H(y+offset+1) = (1 / (sigma * sqrt(2 * pi))) * exp(-0.5 * y^2 / sigma ^2);
    end
    
    D(1) = -1 * (offset - 1);
    for x = -offset+1:-1
       D(x+offset + 1) = D(x+offset) - 1;
    end
    
    D(x+offset+2) = 0;
    D(x+offset+3) = offset;
    for x = 2:offset
       D(x+offset + 1) = D(x+offset) - 1;
    end
    
    Hy = D * H;
    %imagesc(Hx)
    %mesh(Hx)
    
    maxx = max(max(Hy));
    Hy = Hy / maxx;
    %imagesc(Hx)
    
    Hy = Hy * 255;
    %imagesc(Hx)
    
    Hy = round(Hy);
    %imagesc(Hx)
    
    %factor = 255 / Hy(2);
    %Hy = factor * Hy;
    %Hy = uint8(round(Hy)); 
end