function [d] = get_my_guassian_dim(sigma)
%question1: This function creates grayscale image containing four squares
%   This function create a gray scale image of size dxd and draw a square of size d/2xd/2 
%   at the center of image with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your image has four squares

%   Rule of thumb for Gaussian: set filter half-width to about 3 ?

%f(x) = (1 / (sigma * sqrt(2 * pi))) * exp(-0.5 * x^2 / sigma ^2);

%Solving above equation for f(x) = 0 as gaussian will be 0 at edges and sigma we can have x

x = sqrt(-2 * (sigma ^ 2) * log(0.1));

d = 2 * round(x) + 1;

end