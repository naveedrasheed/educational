close all
clear all

I = imread('test_images\circleBlured.png');
colormap gray

%if size(I)
%I = rgb2gray(I);

%I = (zeros(10));
%x = 2;
%y = 5;
%I(x, 1:y) = 255;
%I(3:10, y) = 255;

sigma = 1;

[Hx maxx] = get_x_filter(sigma);
Ix = conv2(double(I),Hx);
%Ix = Ix(2:11, 2:11);
%maxx = max(max(Ix));
%Ix = Ix / maxx;  
%Ix = Ix * 255;
%Ix = round(Ix);

imagesc(Ix)

[Hy maxy] = get_y_filter(sigma);
Iy = conv2(double(I),Hy);
%Iy = Iy(2:11, 2:11);
%maxy = max(max(Iy));
%Iy = Iy / maxy;  
%Iy = Iy * 255;
%Iy = round(Iy);

Ig = sqrt(Ix.*Ix + Iy.*Iy);
Ia = atan2d(Iy,Ix) + 180;

dim = size(Ig);

close all
imagesc(Ia)

t = 10;
for i = 1:dim(1)
    for j = 1:dim(2)
        if(Ig(i,j) <= t)
            Ia(i,j) = 0;% -1
        else
            if((Ig(i,j) >= 0 && Ig(i,j) <= 22.5) || (Ig(i,j) >= 157.5 && Ig(i,j) < 202.5) || (Ig(i,j) >= 337.5 && Ig(i,j) < 360))
                Ia(i,j) = 180;

            elseif((Ig(i,j) >= 22.5 && Ig(i,j) <= 67.5) || (Ig(i,j) >= 202.5 && Ig(i,j) < 247.5))
                Ia(i,j) = 45;

            elseif((Ig(i,j) >= 67.5 && Ig(i,j) <= 112.5) || (Ig(i,j) >= 247.5 && Ig(i,j) < 292.5))
                Ia(i,j) = 90;

            elseif((Ig(i,j) >= 112.5 && Ig(i,j) <= 157.5) || (Ig(i,j) >= 292.5 && Ig(i,j) < 337.5))
                Ia(i,j) = 135;
            end
        end
    end
end

figure
subplot(2,1,1);
imagesc(Ig)

subplot(2,1,2);
imagesc(Ia)
close all

for i = 2:dim(1)-1
    for j = 2:dim(2)-1
        if(Ia(i,j) == 180)
            if(max([Ig(i,j-1) Ig(i,j) Ig(i,j+1)]) ~= Ig(i,j))
               Ig(i,j) = 0;
            end        
        elseif(Ia(i,j) == 45)
            if(max([Ig(i-1,j+1) Ig(i,j) Ig(i+1,j-1)]) ~= Ig(i,j))
               Ig(i,j) = 0;
            end  
        elseif(Ia(i,j) == 90)
            if(max([Ig(i-1,j) Ig(i,j) Ig(i+1,j)]) ~= Ig(i,j))
               Ig(i,j) = 0;
            end  
        elseif(Ia(i,j) == 135)
            if(max([Ig(i-1,j-1) Ig(i,j) Ig(i+1,j+1)]) ~= Ig(i,j))
               Ig(i,j) = 0;
            end  
        end
    end
end

s = size(Hx)/2;
offset = floor(s(1));

Ig = Ig(offset+1:dim(1)-offset, offset+1:dim(2)-offset);
maxx = max(max(Ig));
Ig = Ig / maxx;

Th = 0.8;
Tl = 0.32;

for i = 1:dim(1)-offset*2
    for j = 1:dim(2)-offset*2
        if(Ig(i,j) < Tl)
            Ig(i,j) = 0;
        end
        
        if(Ig(i,j) > Th)
            Ig(i,j) = 0;
        end
    end
end

imagesc(Ig)

%G = Gx * Gy;
%Igsmooth = conv2(I,G);
%Igsmooth = Igsmooth(2:11, 2:11);