function [Hy maxy] = get_y_filter(sigma)
%question1: This function creates grayscale image containing four squares
%   This function create a gray scale image of size dxd and draw a square of size d/2xd/2 
%   at the center of image with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your image has four squares

    d = get_my_guassian_dim(sigma);
    offset = floor(d/2);

    Hy = zeros(d);
    
    for x = -offset:offset
        for y = -offset:offset
            Hy(x+offset + 1,y+offset + 1) = -y/(sigma ^2) * compute_guassian(x,y,sigma);
        end
    end
    
    maxy = max(max(Hy));
    Hy = Hy / maxy;
    %imagesc(Hx)
    
    Hy = Hy * 255;
    %imagesc(Hx)
    
    Hy = round(Hy);
    %imagesc(Hx)
end