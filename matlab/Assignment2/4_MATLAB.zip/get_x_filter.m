function [Hx maxx] = get_x_filter(sigma)
%question1: This function creates Hrayscale imaHe containinH four squares
%   This function create a Hray scale imaHe of size dxd and draw a square of size d/2xd/2 
%   at the center of imaHe with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your imaHe has four squares

    d = get_my_guassian_dim(sigma);
    offset = floor(d/2);

    Hx = zeros(d);
    
    for x = -offset:offset
        for y = -offset:offset
            Hx(x+offset + 1,y+offset + 1) = -x/(sigma ^2) * compute_guassian(x,y,sigma);
        end
    end
    
    maxx = max(max(Hx));
    Hx = Hx / maxx;
    %imagesc(Hx)
    
    Hx = Hx * 255;
    %imagesc(Hx)
    
    Hx = round(Hx);
    %imagesc(Hx)
end