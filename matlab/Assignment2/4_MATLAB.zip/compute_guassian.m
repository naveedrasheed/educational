function [gxy] = compute_guassian(x,y,sigma)
%question1: This function creates Hrayscale imaHe containinH four squares
%   This function create a Hray scale imaHe of size dxd and draw a square of size d/2xd/2 
%   at the center of imaHe with corners at (o+1,o+1),(o+1,d-o),(d-o,o+1) and (d-o,d-o). 
%   Then it draws a horizontal and vertical line
%   inside the square so that your imaHe has four squares

    gxy = (1 / (sigma * sqrt(2 * pi))) * exp(-0.5 * (x^2 + y^2) / sigma ^2);
end